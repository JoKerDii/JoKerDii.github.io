https://github.com/jaaack-wang/Notes-for-Stanford-CS224N-NLP-with-Deep-Learning
